{
    'name': 'Over Receipt Approval',
    'version': '1.0',
    'depends': ['stock'],
    'data': [],
    'installable': True,
    'application': False,
}